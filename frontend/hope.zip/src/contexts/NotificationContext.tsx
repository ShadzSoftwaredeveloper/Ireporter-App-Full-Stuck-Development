import React, { createContext, useContext, useState, useEffect } from 'react';
import { Notification, NotificationContextType } from '../types';
import { useAuth } from './AuthContext';
import { toast } from 'sonner@2.0.3';
import { API_ENDPOINTS, getAuthHeaders } from '../config/api';

const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

export const useNotifications = () => {
  const context = useContext(NotificationContext);
  if (!context) {
    throw new Error('useNotifications must be used within NotificationProvider');
  }
  return context;
};

interface NotificationProviderProps {
  children: React.ReactNode;
}

export const NotificationProvider: React.FC<NotificationProviderProps> = ({ children }) => {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();

  // Fetch notifications from backend
  useEffect(() => {
    const fetchNotifications = async () => {
      if (!user) {
        setNotifications([]);
        setLoading(false);
        return;
      }

      try {
        const response = await fetch(API_ENDPOINTS.NOTIFICATIONS, {
          headers: getAuthHeaders(),
        });

        if (response.ok) {
          const data = await response.json();
          setNotifications(data.data.notifications || []);
        } else {
          console.error('Failed to fetch notifications');
          setNotifications([]);
        }
      } catch (error) {
        console.error('Error fetching notifications:', error);
        setNotifications([]);
      } finally {
        setLoading(false);
      }
    };

    fetchNotifications();
  }, [user]);

  const addNotification = async (notification: Omit<Notification, 'id' | 'createdAt' | 'read'>) => {
    try {
      const response = await fetch(API_ENDPOINTS.NOTIFICATIONS, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeaders(),
        },
        body: JSON.stringify(notification),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || 'Failed to create notification');
      }

      const newNotification = data.data.notification;
      setNotifications([newNotification, ...notifications]);

      // Show toast notification
      const notificationType = notification.type === 'new-incident' ? '🆕' : '📊';
      toast.success(`${notificationType} ${notification.message}`);
    } catch (error) {
      console.error('Error adding notification:', error);
    }
  };

  const markAsRead = async (notificationId: string) => {
    try {
      const response = await fetch(API_ENDPOINTS.MARK_READ(notificationId), {
        method: 'PATCH',
        headers: getAuthHeaders(),
      });

      if (response.ok) {
        const updatedNotifications = notifications.map((notification) =>
          notification.id === notificationId
            ? { ...notification, read: true }
            : notification
        );
        setNotifications(updatedNotifications);
      }
    } catch (error) {
      console.error('Error marking notification as read:', error);
    }
  };

  const markAllAsRead = async () => {
    if (!user) return;
    
    try {
      const response = await fetch(API_ENDPOINTS.MARK_ALL_READ, {
        method: 'PATCH',
        headers: getAuthHeaders(),
      });

      if (response.ok) {
        const updatedNotifications = notifications.map((notification) =>
          notification.userId === user.id
            ? { ...notification, read: true }
            : notification
        );
        setNotifications(updatedNotifications);
      }
    } catch (error) {
      console.error('Error marking all notifications as read:', error);
    }
  };

  const deleteNotification = async (notificationId: string) => {
    try {
      const response = await fetch(API_ENDPOINTS.NOTIFICATION_BY_ID(notificationId), {
        method: 'DELETE',
        headers: getAuthHeaders(),
      });

      if (response.ok) {
        const updatedNotifications = notifications.filter(
          (notification) => notification.id !== notificationId
        );
        setNotifications(updatedNotifications);
      }
    } catch (error) {
      console.error('Error deleting notification:', error);
    }
  };

  const getUserNotifications = (userId: string) => {
    return notifications
      .filter((notification) => notification.userId === userId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  };

  const unreadCount = user
    ? notifications.filter((n) => n.userId === user.id && !n.read).length
    : 0;

  return (
    <NotificationContext.Provider
      value={{
        notifications,
        unreadCount,
        addNotification,
        markAsRead,
        markAllAsRead,
        deleteNotification,
        getUserNotifications,
      }}
    >
      {children}
    </NotificationContext.Provider>
  );
};