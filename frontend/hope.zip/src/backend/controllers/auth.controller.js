const jwt = require('jsonwebtoken');
const { User, OTP } = require('../models');
const { sendOTPEmail } = require('../utils/emailService');

// Generate JWT token
const generateToken = (userId) => {
  return jwt.sign(
    { id: userId },
    process.env.JWT_SECRET || 'your-secret-key',
    { expiresIn: process.env.JWT_EXPIRE || '7d' }
  );
};

// Generate 6-digit OTP
const generateOTP = () => {
  return Math.floor(100000 + Math.random() * 900000).toString();
};

// @route   POST /api/auth/send-otp
// @desc    Send OTP for registration
// @access  Public
const sendOTP = async (req, res) => {
  try {
    const { email, purpose = 'registration' } = req.body;

    if (!email) {
      return res.status(400).json({
        status: 'error',
        message: 'Email is required'
      });
    }

    // Check if user already exists (for registration)
    if (purpose === 'registration') {
      const existingUser = await User.findOne({ where: { email } });
      if (existingUser) {
        return res.status(400).json({
          status: 'error',
          message: 'User with this email already exists'
        });
      }
    }

    // Delete any existing OTPs for this email and purpose
    await OTP.destroy({
      where: { email, purpose }
    });

    // Generate OTP
    const otp = generateOTP();
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes

    // Save OTP to database
    await OTP.create({
      email,
      otp,
      purpose,
      expiresAt
    });

    // Send OTP email
    await sendOTPEmail(email, otp, purpose);

    res.json({
      status: 'success',
      message: 'OTP sent successfully to your email'
    });
  } catch (error) {
    console.error('Send OTP error:', error);
    res.status(500).json({
      status: 'error',
      message: 'Error sending OTP',
      error: error.message
    });
  }
};

// @route   POST /api/auth/verify-otp
// @desc    Verify OTP
// @access  Public
const verifyOTP = async (req, res) => {
  try {
    const { email, otp, purpose = 'registration' } = req.body;

    if (!email || !otp) {
      return res.status(400).json({
        status: 'error',
        message: 'Email and OTP are required'
      });
    }

    // Find OTP record
    const otpRecord = await OTP.findOne({
      where: {
        email,
        otp,
        purpose,
        verified: false
      },
      order: [['createdAt', 'DESC']]
    });

    if (!otpRecord) {
      return res.status(400).json({
        status: 'error',
        message: 'Invalid OTP'
      });
    }

    // Check if OTP has expired
    if (new Date() > otpRecord.expiresAt) {
      return res.status(400).json({
        status: 'error',
        message: 'OTP has expired. Please request a new one.'
      });
    }

    // Check attempts (max 5)
    if (otpRecord.attempts >= 5) {
      return res.status(400).json({
        status: 'error',
        message: 'Maximum attempts exceeded. Please request a new OTP.'
      });
    }

    // Increment attempts
    await otpRecord.update({
      attempts: otpRecord.attempts + 1
    });

    // If OTP doesn't match
    if (otpRecord.otp !== otp) {
      return res.status(400).json({
        status: 'error',
        message: 'Invalid OTP'
      });
    }

    // Mark OTP as verified
    await otpRecord.update({ verified: true });

    res.json({
      status: 'success',
      message: 'OTP verified successfully'
    });
  } catch (error) {
    console.error('Verify OTP error:', error);
    res.status(500).json({
      status: 'error',
      message: 'Error verifying OTP',
      error: error.message
    });
  }
};

// @route   POST /api/auth/signup
// @desc    Register new user
// @access  Public
const signup = async (req, res) => {
  try {
    const { email, password, name, otp } = req.body;

    // Validate input
    if (!email || !password || !name || !otp) {
      return res.status(400).json({
        status: 'error',
        message: 'Please provide email, password, name, and OTP'
      });
    }

    // Verify OTP first
    const otpRecord = await OTP.findOne({
      where: {
        email,
        otp,
        purpose: 'registration',
        verified: true
      },
      order: [['createdAt', 'DESC']]
    });

    if (!otpRecord) {
      return res.status(400).json({
        status: 'error',
        message: 'Please verify your email with OTP first'
      });
    }

    // Check if user already exists
    const existingUser = await User.findOne({ where: { email } });
    if (existingUser) {
      return res.status(400).json({
        status: 'error',
        message: 'User with this email already exists'
      });
    }

    // Create user (password will be hashed by the model hook)
    // All users are created with 'user' role by default
    const user = await User.create({
      email,
      password,
      name,
      role: 'user',
      emailVerified: true // Mark as verified since OTP was confirmed
    });

    // Delete used OTP
    await OTP.destroy({
      where: { email, purpose: 'registration' }
    });

    // Generate token
    const token = generateToken(user.id);

    res.status(201).json({
      status: 'success',
      message: 'User registered successfully',
      data: {
        user,
        token
      }
    });
  } catch (error) {
    console.error('Signup error:', error);
    res.status(500).json({
      status: 'error',
      message: 'Error creating user',
      error: error.message
    });
  }
};

// @route   POST /api/auth/signin
// @desc    Login user
// @access  Public
const signin = async (req, res) => {
  try {
    const { email, password } = req.body;

    // Validate input
    if (!email || !password) {
      return res.status(400).json({
        status: 'error',
        message: 'Please provide email and password'
      });
    }

    // Find user (need to include password for comparison)
    const user = await User.findOne({
      where: { email },
      attributes: { include: ['password'] }
    });

    if (!user) {
      return res.status(401).json({
        status: 'error',
        message: 'Invalid email or password'
      });
    }

    // Check password
    const isPasswordValid = await user.comparePassword(password);
    if (!isPasswordValid) {
      return res.status(401).json({
        status: 'error',
        message: 'Invalid email or password'
      });
    }

    // Generate token
    const token = generateToken(user.id);

    // Remove password from response
    const userResponse = user.toJSON();

    res.json({
      status: 'success',
      message: 'Login successful',
      data: {
        user: userResponse,
        token
      }
    });
  } catch (error) {
    console.error('Signin error:', error);
    res.status(500).json({
      status: 'error',
      message: 'Error signing in',
      error: error.message
    });
  }
};

// @route   GET /api/auth/me
// @desc    Get current user
// @access  Private
const getMe = async (req, res) => {
  try {
    const user = await User.findByPk(req.user.id);
    
    res.json({
      status: 'success',
      data: { user }
    });
  } catch (error) {
    console.error('Get me error:', error);
    res.status(500).json({
      status: 'error',
      message: 'Error fetching user data',
      error: error.message
    });
  }
};

// @route   PUT /api/auth/profile
// @desc    Update user profile
// @access  Private
const updateProfile = async (req, res) => {
  try {
    const { name, email, profilePicture } = req.body;

    const user = await User.findByPk(req.user.id);

    if (!user) {
      return res.status(404).json({
        status: 'error',
        message: 'User not found'
      });
    }

    // Check if email is being changed and if it's already taken
    if (email && email !== user.email) {
      const existingUser = await User.findOne({ where: { email } });
      if (existingUser) {
        return res.status(400).json({
          status: 'error',
          message: 'Email already in use'
        });
      }
    }

    // Update user
    await user.update({
      name: name || user.name,
      email: email || user.email,
      profilePicture: profilePicture || user.profilePicture
    });

    res.json({
      status: 'success',
      message: 'Profile updated successfully',
      data: { user }
    });
  } catch (error) {
    console.error('Update profile error:', error);
    res.status(500).json({
      status: 'error',
      message: 'Error updating profile',
      error: error.message
    });
  }
};

module.exports = {
  signup,
  signin,
  getMe,
  updateProfile,
  sendOTP,
  verifyOTP
};