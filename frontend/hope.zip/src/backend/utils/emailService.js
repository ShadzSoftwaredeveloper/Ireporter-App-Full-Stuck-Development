const nodemailer = require('nodemailer');

// Create email transporter
const createTransporter = () => {
  // Check if we're using SendGrid or SMTP
  if (process.env.EMAIL_SERVICE === 'sendgrid') {
    return nodemailer.createTransport({
      host: 'smtp.sendgrid.net',
      port: 587,
      auth: {
        user: 'apikey',
        pass: process.env.SENDGRID_API_KEY
      }
    });
  } else if (process.env.EMAIL_SERVICE === 'gmail') {
    return nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASSWORD
      }
    });
  } else {
    // Default SMTP configuration
    return nodemailer.createTransport({
      host: process.env.SMTP_HOST || 'smtp.mailtrap.io',
      port: process.env.SMTP_PORT || 2525,
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASSWORD
      }
    });
  }
};

// Send email to admin when incident is created
const sendIncidentCreatedEmail = async (admin, incident, createdBy) => {
  try {
    const transporter = createTransporter();
    const incidentType = incident.type === 'red-flag' ? 'Red-flag' : 'Intervention';
    
    const mailOptions = {
      from: process.env.EMAIL_FROM || 'noreply@incidentreporting.com',
      to: admin.email,
      subject: `🚨 New ${incidentType} Incident Reported`,
      html: `
        <!DOCTYPE html>
        <html>
        <head>
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%); color: white; padding: 30px; text-align: center; border-radius: 8px 8px 0 0; }
            .content { background: #f9fafb; padding: 30px; border-radius: 0 0 8px 8px; }
            .incident-box { background: white; border-left: 4px solid #ef4444; padding: 20px; margin: 20px 0; border-radius: 4px; }
            .footer { text-align: center; margin-top: 30px; color: #6b7280; font-size: 14px; }
            .button { display: inline-block; padding: 12px 24px; background: #ef4444; color: white; text-decoration: none; border-radius: 6px; margin-top: 20px; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>🚨 New Incident Alert</h1>
            </div>
            <div class="content">
              <p>Dear ${admin.name},</p>
              <p>A new ${incidentType.toLowerCase()} incident has been reported by <strong>${createdBy.name}</strong>.</p>
              
              <div class="incident-box">
                <h3>Incident Details</h3>
                <p><strong>Title:</strong> ${incident.title}</p>
                <p><strong>Type:</strong> ${incidentType}</p>
                <p><strong>Status:</strong> ${incident.status.split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ')}</p>
                <p><strong>Location:</strong> ${incident.location.address || `${incident.location.lat}, ${incident.location.lng}`}</p>
                <p><strong>Reported on:</strong> ${new Date(incident.createdAt).toLocaleString('en-US', {
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric',
                  hour: '2-digit',
                  minute: '2-digit',
                })}</p>
                
                <h4>Description:</h4>
                <p>${incident.description}</p>
              </div>

              <p>Please review this incident and take appropriate action.</p>
              
              <p>Best regards,<br>Incident Reporting System</p>
            </div>
            <div class="footer">
              <p>This is an automated message from the Incident Reporting System.</p>
            </div>
          </div>
        </body>
        </html>
      `
    };

    const info = await transporter.sendMail(mailOptions);
    console.log('✅ Email sent to admin:', admin.email, '| Message ID:', info.messageId);
    return info;
  } catch (error) {
    console.error('❌ Error sending email to admin:', admin.email, error);
    throw error;
  }
};

// Send email to user when status is updated
const sendStatusUpdateEmail = async (user, incident, oldStatus, newStatus) => {
  try {
    const transporter = createTransporter();
    const statusText = newStatus.split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
    const oldStatusText = oldStatus.split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
    
    let statusEmoji = '📊';
    let statusColor = '#3b82f6';
    if (newStatus === 'resolved') {
      statusEmoji = '✅';
      statusColor = '#22c55e';
    }
    if (newStatus === 'rejected') {
      statusEmoji = '❌';
      statusColor = '#ef4444';
    }
    if (newStatus === 'under-investigation') {
      statusEmoji = '🔍';
      statusColor = '#3b82f6';
    }
    
    const mailOptions = {
      from: process.env.EMAIL_FROM || 'noreply@incidentreporting.com',
      to: user.email,
      subject: `${statusEmoji} Incident Status Updated: ${incident.title}`,
      html: `
        <!DOCTYPE html>
        <html>
        <head>
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, ${statusColor} 0%, ${statusColor}dd 100%); color: white; padding: 30px; text-align: center; border-radius: 8px 8px 0 0; }
            .content { background: #f9fafb; padding: 30px; border-radius: 0 0 8px 8px; }
            .status-box { background: white; border-left: 4px solid ${statusColor}; padding: 20px; margin: 20px 0; border-radius: 4px; }
            .status-badge { display: inline-block; padding: 8px 16px; background: ${statusColor}; color: white; border-radius: 20px; font-size: 14px; }
            .footer { text-align: center; margin-top: 30px; color: #6b7280; font-size: 14px; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>${statusEmoji} Status Update</h1>
            </div>
            <div class="content">
              <p>Dear ${user.name},</p>
              <p>Your incident report has been updated by an administrator.</p>
              
              <div class="status-box">
                <h3>${incident.title}</h3>
                <p><strong>Previous Status:</strong> ${oldStatusText}</p>
                <p><strong>New Status:</strong> <span class="status-badge">${statusText}</span></p>
                
                ${incident.adminComment ? `
                  <h4>Admin Comment:</h4>
                  <p>${incident.adminComment}</p>
                ` : ''}
                
                <p><strong>Last Updated:</strong> ${new Date(incident.updatedAt).toLocaleString('en-US', {
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric',
                  hour: '2-digit',
                  minute: '2-digit',
                })}</p>
              </div>

              <p>You can view the full incident details through your dashboard.</p>
              
              <p>Thank you for using our incident reporting system.</p>
              
              <p>Best regards,<br>Incident Reporting System</p>
            </div>
            <div class="footer">
              <p>This is an automated message from the Incident Reporting System.</p>
            </div>
          </div>
        </body>
        </html>
      `
    };

    const info = await transporter.sendMail(mailOptions);
    console.log('✅ Email sent to user:', user.email, '| Message ID:', info.messageId);
    return info;
  } catch (error) {
    console.error('❌ Error sending email to user:', user.email, error);
    throw error;
  }
};

// Test email configuration
const testEmailConnection = async () => {
  try {
    const transporter = createTransporter();
    await transporter.verify();
    console.log('✅ Email server connection verified');
    return true;
  } catch (error) {
    console.error('❌ Email server connection failed:', error.message);
    return false;
  }
};

// Send OTP email for verification
const sendOTPEmail = async (email, otp, purpose = 'registration') => {
  try {
    const transporter = createTransporter();
    
    let subject, title, message;
    
    if (purpose === 'registration') {
      subject = '🔐 Verify Your Email - OTP Code';
      title = 'Email Verification';
      message = 'Thank you for registering! Please use the OTP below to verify your email address.';
    } else if (purpose === 'password_reset') {
      subject = '🔑 Password Reset - OTP Code';
      title = 'Password Reset Request';
      message = 'You requested to reset your password. Use the OTP below to proceed.';
    } else {
      subject = '🔐 Login Verification - OTP Code';
      title = 'Login Verification';
      message = 'Please use the OTP below to complete your login.';
    }
    
    const mailOptions = {
      from: process.env.EMAIL_FROM || 'noreply@incidentreporting.com',
      to: email,
      subject,
      html: `
        <!DOCTYPE html>
        <html>
        <head>
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%); color: white; padding: 30px; text-align: center; border-radius: 8px 8px 0 0; }
            .content { background: #f9fafb; padding: 30px; border-radius: 0 0 8px 8px; }
            .otp-box { background: white; border: 2px dashed #3b82f6; padding: 30px; margin: 30px 0; text-align: center; border-radius: 8px; }
            .otp-code { font-size: 36px; font-weight: bold; color: #3b82f6; letter-spacing: 8px; margin: 20px 0; }
            .footer { text-align: center; margin-top: 30px; color: #6b7280; font-size: 14px; }
            .warning { background: #fef3c7; border-left: 4px solid #f59e0b; padding: 15px; margin: 20px 0; border-radius: 4px; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>🔐 ${title}</h1>
            </div>
            <div class="content">
              <p>${message}</p>
              
              <div class="otp-box">
                <p style="margin: 0; font-size: 14px; color: #6b7280;">Your OTP Code</p>
                <div class="otp-code">${otp}</div>
                <p style="margin: 0; font-size: 14px; color: #6b7280;">Valid for 10 minutes</p>
              </div>

              <div class="warning">
                <strong>⚠️ Security Notice:</strong>
                <ul style="margin: 10px 0;">
                  <li>This OTP will expire in 10 minutes</li>
                  <li>Never share this code with anyone</li>
                  <li>If you didn't request this, please ignore this email</li>
                </ul>
              </div>
              
              <p>Best regards,<br>Incident Reporting System</p>
            </div>
            <div class="footer">
              <p>This is an automated message from the Incident Reporting System.</p>
            </div>
          </div>
        </body>
        </html>
      `
    };

    const info = await transporter.sendMail(mailOptions);
    console.log('✅ OTP email sent to:', email, '| Message ID:', info.messageId);
    return info;
  } catch (error) {
    console.error('❌ Error sending OTP email to:', email, error);
    throw error;
  }
};

module.exports = {
  sendIncidentCreatedEmail,
  sendStatusUpdateEmail,
  testEmailConnection,
  sendOTPEmail
};